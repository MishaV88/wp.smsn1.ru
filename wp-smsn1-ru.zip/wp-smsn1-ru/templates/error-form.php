<div class="wp-smsn1-ru-form">
    <h2>Упс, что-то не так!</h2>
    <form id="wp-smsn1-ru-login-form">
        <button type="button" class="wide" onclick="location.href='/wp-login.php';" >Стандартная форма авторизации WordPress</button>
		<!-- <button type="button" class="wide" onclick="location.href='/my-account/';" >Стандартная форма авторизации WooCommerce</button>-->
    </form>
    <div id="wp-smsn1-ru-message">Проблема с плагином СМС-авторизации, пожалуйста попробуйте <a href="/wp-login.php">стандартную форму</a>.</div>
	</p>
</div>