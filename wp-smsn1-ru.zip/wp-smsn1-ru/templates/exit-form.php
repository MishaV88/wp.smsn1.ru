<div class="wp-smsn1-ru-form">
	<p>Вы уже авторизованы.</p>
	<button type="button" onclick="location.href='<?= wp_logout_url(home_url()); ?>';" >Выход</button>
</div>